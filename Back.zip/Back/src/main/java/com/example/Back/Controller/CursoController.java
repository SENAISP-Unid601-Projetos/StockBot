package com.example.Back.Controller;

public class CursoController {
}
