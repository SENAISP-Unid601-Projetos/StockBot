package com.example.Back.Controller;



public class UsuarioController {
}
