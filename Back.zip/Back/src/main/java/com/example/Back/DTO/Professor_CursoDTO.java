package com.example.Back.DTO;

public class Professor_CursoDTO {
}
