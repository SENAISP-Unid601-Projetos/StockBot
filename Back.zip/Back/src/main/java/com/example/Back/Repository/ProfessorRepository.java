package com.example.Back.Repository;

import com.example.Back.Entity.Professor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfessorRepository extends JpaRepository<Long, Professor> {
}
