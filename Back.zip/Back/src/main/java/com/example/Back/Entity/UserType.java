package com.example.Back.Entity;

public enum UserType {
    PROFESSOR,
    ALUNO
}
