package com.example.Back.Service;

public class Professor_CursoService {
}
