package com.example.Back.Repository;

public interface Professor_CursoRepository {
}
