package com.example.Back.Controller;

public class Professor_CursoController {
}
