package com.example.Back.Entity;

public class Professor_Curso {
}
