package com.example.Back.Entity;

public enum MatriculaStatus {
    ATIVA,
    INATIVA,
    TRANCADA,
    CANCELADA
}
